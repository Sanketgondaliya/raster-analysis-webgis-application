//src/environments/environment.ts
export const environment = {
  production: false,
  apiBaseUrl: "http://localhost:3000/api",
  // apiBaseUrl: "http://localhost:3000/api",
  authToken: "PX8m78xte0gCHALszzcFR04gV45252C9",
};
