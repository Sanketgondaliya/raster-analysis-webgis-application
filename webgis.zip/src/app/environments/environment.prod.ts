// src/environments/environment.prod.ts
export const environment = {
  production: true,
  apiBaseUrl: "http://192.168.10.146:8088/api",
  authToken: "2xldh9b96sGG0FweBbwVTwRhqoLvQMrj",
  helpDocBaseUrl: "http://192.168.20.58",
};
